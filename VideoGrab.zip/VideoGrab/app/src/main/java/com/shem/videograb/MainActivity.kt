package com.shem.videograb

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        try { YoutubeDL.getInstance().init(this); FFmpeg.getInstance().init(this) } catch (_: Exception) {}
    }
}

class Dl(val id: String, val url: String, val title: String, val fmt: String, val audio: Boolean, val transcribe: Boolean) {
    var status by mutableStateOf("Starting")
    var pct by mutableFloatStateOf(0f)
    var info by mutableStateOf("")
    var job: Job? = null
    fun dir(ctx: Context) = File(ctx.cacheDir, "dl/$id")
}
class Item(val name: String, val uri: String)

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val downloads = mutableStateListOf<Dl>()
    private val history = mutableStateListOf<Item>()
    private var url by mutableStateOf("")
    private var title by mutableStateOf<String?>(null)
    private var heights by mutableStateOf(listOf<Int>())
    private var sel by mutableIntStateOf(0) // 0 = best, -1 = MP3, else max height
    private var msg by mutableStateOf("")
    private var busy by mutableStateOf(false)
    private var transcribe by mutableStateOf(false)
    private var apiKey by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getSharedPreferences("h", 0).getString("items", "")!!.lines().filter { it.contains("\t") }
            .forEach { val p = it.split("\t"); history.add(Item(p[0], p[1])) }
        apiKey = getSharedPreferences("h", 0).getString("gkey", "") ?: ""
        scope.launch { try { YoutubeDL.getInstance().updateYoutubeDL(applicationContext, YoutubeDL.UpdateChannel.STABLE) } catch (_: Exception) {} }
        handle(intent)
        setContent { MaterialTheme { Screen() } }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handle(intent) }

    private fun handle(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val u = Regex("https?://\\S+").find(i.getStringExtra(Intent.EXTRA_TEXT) ?: "")?.value ?: return
        url = u; analyze()
    }

    private fun analyze() {
        if (url.isBlank() || busy) return
        busy = true; msg = ""; title = null
        scope.launch {
            try {
                val info = YoutubeDL.getInstance().getInfo(url.trim())
                heights = info.formats?.map { it.height }?.filter { it >= 144 }?.distinct()?.sortedDescending() ?: listOf()
                sel = 0; title = info.title ?: "Video"
            } catch (e: Exception) {
                msg = "Can't download this link: " + (e.message?.lines()?.lastOrNull { it.isNotBlank() } ?: "unsupported or protected")
            }
            busy = false
        }
    }

    private fun start() {
        val a = "[vcodec^=avc1]"
        val fmt = when {
            sel < 0 -> "ba[ext=m4a]/ba/b"
            sel == 0 -> "bv*${a}+ba[ext=m4a]/b${a}/bv*+ba/b"
            else -> "bv*${a}[height<=$sel]+ba[ext=m4a]/b${a}[height<=$sel]/bv*[height<=$sel]+ba/b[height<=$sel]/b"
        }
        val tr = transcribe && sel >= 0
        if (tr && apiKey.isBlank()) { msg = "Paste your Groq API key first (or turn off Transcribe)."; return }
        val d = Dl(UUID.randomUUID().toString(), url.trim(), title ?: url, fmt, sel < 0, tr)
        downloads.add(0, d); title = null; url = ""; run(d)
    }

    private fun run(d: Dl) {
        d.status = "Downloading"
        d.job = scope.launch {
            try {
                val r = YoutubeDLRequest(d.url)
                r.addOption("-o", d.dir(this@MainActivity).absolutePath + "/%(title).80s.%(ext)s")
                r.addOption("-f", d.fmt); r.addOption("-c"); r.addOption("--no-mtime"); r.addOption("--no-playlist"); r.addOption("--restrict-filenames")
                if (d.audio) { r.addOption("-x"); r.addOption("--audio-format", "mp3") } else {
                    r.addOption("--merge-output-format", "mp4")
                    if (d.transcribe) { r.addOption("-x"); r.addOption("-k"); r.addOption("--audio-format", "mp3"); r.addOption("--ppa", "ExtractAudio:-ac 1 -ar 16000 -b:a 32k") }
                }
                YoutubeDL.getInstance().execute(r, d.id) { p, eta, line ->
                    if (p >= 0) d.pct = p / 100f
                    val m = Regex("of\\s+~?\\s*([\\d.]+\\S+)\\s+at\\s+([\\d.]+\\S+/s)").find(line)
                    if (m != null) d.info = "${m.groupValues[1]} • ${m.groupValues[2]} • ETA ${eta}s"
                }
                d.status = "Saving"
                val files = d.dir(this@MainActivity).listFiles()?.filter { !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") } ?: listOf()
                val f = (if (d.audio) files.filter { it.extension == "mp3" } else files.filter { it.extension == "mp4" })
                    .maxByOrNull { it.length() } ?: error("No file produced")
                val audioF = if (d.transcribe) files.firstOrNull { it.extension == "mp3" } else null
                val uri = save(f)
                history.add(0, Item(f.name, uri))
                if (audioF != null) {
                    d.status = "Transcribing"; d.info = "Whisper large-v3…"
                    try {
                        val (srt, txt) = whisper(audioF)
                        val base = f.nameWithoutExtension
                        for ((ext, body) in listOf("txt" to txt, "srt" to srt)) {
                            val t = File(d.dir(this@MainActivity), "$base.$ext"); t.writeText(body)
                            history.add(0, Item(t.name, save(t)))
                        }
                        d.status = "Done"
                    } catch (e: Exception) { d.status = "Done (transcript failed: " + (e.message ?: "error").take(120) + ")" }
                } else d.status = "Done"
                persist(); d.pct = 1f; d.dir(this@MainActivity).deleteRecursively()
            } catch (e: Exception) {
                if (d.status == "Downloading" || d.status == "Saving")
                    d.status = "Error: " + (e.message?.lines()?.lastOrNull { it.isNotBlank() }?.take(140) ?: "failed")
            }
        }
    }

    private fun pause(d: Dl) { d.status = "Paused"; YoutubeDL.getInstance().destroyProcessById(d.id) }
    private fun cancel(d: Dl) {
        d.status = "Canceled"; YoutubeDL.getInstance().destroyProcessById(d.id)
        d.dir(this).deleteRecursively(); downloads.remove(d)
    }

    private fun save(f: File): String {
        val (mime, col, rel) = when (f.extension) {
            "mp3" -> Triple("audio/mpeg", MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "Music/VideoGrab")
            "mp4" -> Triple("video/mp4", MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "Movies/VideoGrab")
            "srt" -> Triple("application/x-subrip", MediaStore.Downloads.EXTERNAL_CONTENT_URI, "Download/VideoGrab")
            else -> Triple("text/plain", MediaStore.Downloads.EXTERNAL_CONTENT_URI, "Download/VideoGrab")
        }
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
        }
        val uri = contentResolver.insert(col, v)!!
        contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        return uri.toString()
    }

    private fun ts(t: Double): String {
        val ms = (t * 1000).toLong()
        return "%02d:%02d:%02d,%03d".format(ms / 3600000, ms / 60000 % 60, ms / 1000 % 60, ms % 1000)
    }

    // Groq Whisper large-v3 (OpenAI-compatible endpoint). Returns (srt, txt).
    private fun whisper(f: File): Pair<String, String> {
        if (f.length() > 24_000_000) error("audio over 25 MB (video too long for one request)")
        val b = "----vg" + System.currentTimeMillis()
        val c = URL("https://api.groq.com/openai/v1/audio/transcriptions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.setChunkedStreamingMode(0)
        c.connectTimeout = 30000; c.readTimeout = 600000
        c.setRequestProperty("Authorization", "Bearer " + apiKey.trim())
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
        c.outputStream.use { o ->
            fun field(n: String, v: String) = o.write("--$b\r\nContent-Disposition: form-data; name=\"$n\"\r\n\r\n$v\r\n".toByteArray())
            field("model", "whisper-large-v3"); field("response_format", "verbose_json"); field("temperature", "0")
            o.write("--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"a.mp3\"\r\nContent-Type: audio/mpeg\r\n\r\n".toByteArray())
            f.inputStream().use { it.copyTo(o) }
            o.write("\r\n--$b--\r\n".toByteArray())
        }
        val code = c.responseCode
        val body = (if (code == 200) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code != 200) error("HTTP $code " + (try { JSONObject(body).getJSONObject("error").getString("message") } catch (_: Exception) { body.take(100) }))
        val j = JSONObject(body); val segs = j.getJSONArray("segments"); val srt = StringBuilder()
        for (i in 0 until segs.length()) {
            val s = segs.getJSONObject(i)
            srt.append("${i + 1}\n${ts(s.getDouble("start"))} --> ${ts(s.getDouble("end"))}\n${s.getString("text").trim()}\n\n")
        }
        return srt.toString() to j.getString("text").trim()
    }

    private fun persist() = getSharedPreferences("h", 0).edit()
        .putString("items", history.joinToString("\n") { it.name + "\t" + it.uri }).apply()

    private fun open(i: Item) = try {
        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(i.uri), when (i.name.substringAfterLast(".")) { "mp3" -> "audio/*"; "mp4" -> "video/*"; else -> "text/plain" })
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    } catch (_: Exception) {}

    private fun delete(i: Item) { try { contentResolver.delete(Uri.parse(i.uri), null, null) } catch (_: Exception) {}; history.remove(i); persist() }

    @Composable
    fun Screen() {
        LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("VideoGrab", style = MaterialTheme.typography.headlineMedium)
                OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), label = { Text("Paste video link") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                Button({ analyze() }, Modifier.fillMaxWidth(), enabled = !busy) { Text(if (busy) "Analyzing…" else "Analyze link") }
                if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.error)
                title?.let { t ->
                    Spacer(Modifier.height(8.dp))
                    Text(t, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(sel == 0, { sel = 0 }, { Text("Best MP4") })
                        heights.forEach { h -> FilterChip(sel == h, { sel = h }, { Text("${h}p MP4") }) }
                        FilterChip(sel == -1, { sel = -1 }, { Text("MP3 audio") })
                    }
                    if (sel >= 0) Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(transcribe, { transcribe = it }); Spacer(Modifier.width(8.dp))
                        Text("Transcribe audio (subtitles .srt + text)")
                    }
                    if (sel >= 0 && transcribe) OutlinedTextField(apiKey, {
                        apiKey = it; getSharedPreferences("h", 0).edit().putString("gkey", it).apply()
                    }, Modifier.fillMaxWidth(), label = { Text("Groq API key (console.groq.com)") }, singleLine = true)
                    Button({ start() }, Modifier.fillMaxWidth()) { Text("Download") }
                }
            }
            if (downloads.isNotEmpty()) item { Text("Downloads", style = MaterialTheme.typography.titleLarge) }
            items(downloads.toList(), key = { it.id }) { d ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(d.title, maxLines = 1)
                        LinearProgressIndicator(progress = { d.pct }, Modifier.fillMaxWidth().padding(vertical = 6.dp))
                        Text("${d.status} ${(d.pct * 100).toInt()}%  ${d.info}", style = MaterialTheme.typography.bodySmall)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (d.status == "Downloading") TextButton({ pause(d) }) { Text("Pause") }
                            if (d.status == "Paused" || d.status.startsWith("Error")) TextButton({ run(d) }) { Text(if (d.status == "Paused") "Resume" else "Retry") }
                            if (d.status == "Done") TextButton({ downloads.remove(d) }) { Text("Clear") } else TextButton({ cancel(d) }) { Text("Cancel") }
                        }
                    }
                }
            }
            if (history.isNotEmpty()) item { Text("History / Files", style = MaterialTheme.typography.titleLarge) }
            items(history.toList()) { i ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(i.name, Modifier.weight(1f), maxLines = 2)
                        TextButton({ open(i) }) { Text("Open") }
                        TextButton({ delete(i) }) { Text("Delete") }
                    }
                }
            }
            item { Text("Saved to Movies/VideoGrab (MP3 → Music/VideoGrab)", style = MaterialTheme.typography.bodySmall) }
        }
    }
}
